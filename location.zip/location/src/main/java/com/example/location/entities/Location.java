package com.example.location.entities;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Data
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Loctable")
@JsonInclude(JsonInclude.Include.ALWAYS)

public class Location {

    @Id
    private int locationId;
    private String locName;
    private String locCityName;
    private String locAddress;
    private String locLatitude;
    private String locLongitude;
    private String locImage;
    private int totalInventory;
    private int availableInventory;
    private String workingHours;
    private Boolean availableHours;

}
