package com.example.location.repositary;


import javax.persistence.criteria.CriteriaBuilder.In;

//import com.example.jpa.entity.User;

import com.example.location.entities.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationRepositary extends JpaRepository<Location,Integer> {
    Location getBylocCityName(String locCityName);

    Location getByavailableHours(Boolean availableHours);

    Location getByworkingHours(String workingHours);


//    public Location getByName(String locCityName);

}
