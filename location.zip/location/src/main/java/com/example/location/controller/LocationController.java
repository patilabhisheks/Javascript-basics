package com.example.location.controller;


import com.example.location.entities.Location;
import com.example.location.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LocationController {

    @Autowired
    private LocationService locationService;

    @CrossOrigin
    @PostMapping("/AddLocation")
    public Location createLocation(@RequestBody Location location){
        return locationService.saveLocation(location);
    }

    @CrossOrigin
    @GetMapping("/ShowLocation")
    public List<Location> findalllocation(){
        return locationService.getLocation();
    }

//
    @GetMapping("/Showbyid/{locationId}")
    public Location getLocationById(@PathVariable String locationId){
        Location getlocation = locationService.getLocationById(Integer.valueOf(locationId));
        return getlocation;
    }

    @GetMapping("/showbycity/{locCityName}")
    public Location getLocationByCity(@PathVariable String locCityName){
        Location getLocationcity = locationService.getLocationByCity(locCityName);
        return  getLocationcity;
    }

    @GetMapping("/showavailable/{availableHours}")
    public Location getLocationByavailable(@PathVariable Boolean availableHours){
        Location getLocationByavail = locationService.getLocationByavail(availableHours);
        return getLocationByavail;
    }

    @GetMapping("/showworking/{workingHours}")
    public Location getLocationByworking(@PathVariable String workingHours){
        Location getLocationByworking =locationService.getLocationByworking(workingHours);
        return getLocationByworking;
    }

    @CrossOrigin
    @PutMapping("/updateLocation")
    public Location updateLocation(@RequestBody Location location){
       return locationService.updateLocation(location);
    }

    @DeleteMapping("/deleteLocation")
    public String deleteLocatuin(@RequestParam int locationId) {
        locationService.deleteLocation(locationId);
        return "delete Successfully";
    }

}