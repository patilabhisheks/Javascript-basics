package com.example.location.service;


import com.example.location.entities.Location;
import com.example.location.repositary.LocationRepositary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LocationService {

    @Autowired
    private LocationRepositary locationRepositary;

    public Location saveLocation(Location location) {
        return locationRepositary.save(location);
    }

    public List<Location> getLocation() {
        return locationRepositary.findAll();
    }

    public Location updateLocation(Location location) {
        return  locationRepositary.save(location);

    }

    public void deleteLocation(int locationId) {
        locationRepositary.deleteById(locationId);
    }

    public Object getLocation(Integer locationId) {
        return locationRepositary.getById(locationId);
    }


    public Location getLocationById(Integer locationId){
        return locationRepositary.findById(locationId).get();
    }


    public Location getLocationByCity(String locCityName) {
        return  locationRepositary.getBylocCityName(locCityName);
    }


    public Location getLocationByavail(Boolean availableHours) {
        return locationRepositary.getByavailableHours(availableHours);
    }

    public Location getLocationByworking(String workingHours) {
        return locationRepositary.getByworkingHours(workingHours);
    }
}
